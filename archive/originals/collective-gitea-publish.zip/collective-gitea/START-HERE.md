# Publish Collective to your Gitea

## Current status

The architecture and Codex files are prepared locally. **No repository has been
created on your Gitea and no remote upload has been performed by this chat.**
The chat environment could not reach `https://git.m8e.co.uk/` and had no
Gitea login/token/connected integration. This does not establish that your server
is down or inaccessible from your own computer.

This package contains the original v0.2 architecture HTML and every Codex handoff
file, plus a repository README and small hygiene/configuration files. It is a
planning repository, not the implemented assistant.

## Publish on your Windows PC

1. Extract this entire ZIP to a folder of your choice. Do not run from inside the ZIP.
2. Sign in to your own Gitea and open:
   `https://git.m8e.co.uk/user/settings/applications`
   Create a temporary access token with **read:user** and **write:repository**.
   Allow private repositories. Do not restrict it to an existing selected
   repository, because this operation creates a new one. Do not grant admin scope.
3. Double-click `PUBLISH.cmd`, and enter the token in the hidden local prompt.
   Do not paste the token into a chat, source file or command argument.

The publisher uses the authenticated account name. It proposes a **private**
repository called **collective-llm**, on **main**, at the specified Gitea instance.
It creates the repository with its seed README, then publishes all 15 source files
in one additional Git commit using the Gitea API. Git, Node and Python are not
required to run this Windows publisher. It targets Windows PowerShell 5.1+.

Success is reported only after reading every file back at a pinned commit and
comparing SHA-256 hashes. It displays the repository URL, verified commit and
normal `git clone` command. Revoke the temporary token after successful publishing.

The launcher applies execution policy to its own PowerShell process only; it does
not change machine-wide policy, install software, request Administrator access,
modify Cloudflare settings or configure a persistent login.

## What goes into the repository

```text
README.md
AGENTS.md
CODEX_START_PROMPT.txt
.gitignore
.gitattributes
.editorconfig
.agents/skills/collective-build/SKILL.md
docs/BUILD_BACKLOG.md
docs/CODEX_BUILD_BRIEF.md
docs/CODEX_HANDOFF_README.md
docs/MODULE_MAP.md
docs/progress/PROGRESS_TEMPLATE.md
docs/architecture/collective-llm-architecture.html
docs/architecture/collective.proposed.json
docs/architecture/ports.example.ts
```

Only files listed in `publish-manifest.json` are uploaded. The script validates
local paths, sizes and SHA-256 hashes first. The publisher, token prompt and local
receipt remain outside the uploaded repository. Extra local files are not uploaded.

## Existing repositories and retry behaviour

An existing repository is NOT overwritten just because its name matches. The
publisher resumes only when its local receipt matches the server, authenticated
account, repository ID and exact package manifest. If the remote head has changed,
it checks whether the entire payload is already present before doing anything else.
A mismatch stops the run without force-pushing, deleting, or overwriting files.

Keep `.gitea-publish-state.json` beside the launcher after an interrupted attempt.
It stores IDs and hashes, never the token. A failed POST can have an uncertain
outcome; inspect Gitea before trying another name. There are no blind write retries.
If creation succeeded but the response was lost before its ID was saved, automatic
resume is intentionally refused. Do not delete a repository to fix that refusal.

To choose a different repository name, start with a fresh extraction and run:

```powershell
.\PUBLISH.cmd -RepoName collective-llm-plan
```

To check only the local package without a token or any network requests:

```powershell
.\PUBLISH.cmd -ValidateOnly
```

## Server/API requirements and troubleshooting

Your PC must be able to resolve and reach the HTTPS Gitea instance. The token needs
permission to read its account and create/write private repositories. The instance
must expose the Gitea contents API, including multi-file modification:
`POST /api/v1/repos/{owner}/{repo}/contents`.

- DNS/timeout: check the URL from this PC, the Gitea process and Cloudflare Tunnel.
- HTTP 401/403: check token scopes, account permissions and any Cloudflare Access
  policy. A browser login cookie is not provided to this script. Do not disable
  authentication or make the repository public to work around a failure.
- Redirect/HTML response: an authentication gateway, challenge, or canonical-URL
  redirect may be in the way. The publisher refuses redirects to protect the token.
- HTTP 404/405 during upload: check API support on your installed Gitea version.
- Protected main/signing policy: publication may be refused by existing server
  policy. The script does not disable protections or bypass signing requirements.

TLS certificate validation stays enabled. Authenticated requests go only to the
fixed `https://git.m8e.co.uk` origin; the script does not follow redirects.

## Codex handoff after successful publication

Clone the displayed repository URL into the folder you want to develop in. Read
`AGENTS.md` and supply the text in `CODEX_START_PROMPT.txt` to Codex. The first
unfinished task is T00 when no implementation exists. The build backlog already
covers modules, contracts, testing, permissions, memory, model adapters, scaling,
maintenance, and measured quality/speed gates.

## Validation limits

The archive paths, file manifest, hashes, JSON and preservation of the original
handoff were checked locally. No live Gitea publishing test could be performed from
this chat. PowerShell is not installed in this chat's environment, so the publisher
has not been executed here on Windows. Do not treat it as a completed remote push.

## API references

Official Gitea API authentication and token scopes:
https://docs.gitea.com/development/api-usage/

Official Gitea API reference (repository creation, file contents, multi-file changes):
https://docs.gitea.com/api/1.24/

Check the actual instance's API definitions when needed:
`https://git.m8e.co.uk/api/swagger`
`https://git.m8e.co.uk/swagger.v1.json`
