#Requires -Version 5.1
<#
Create a private Gitea repository and publish ONLY the supplied manifest files.
Uses the Gitea contents API to create a Git commit; Git is not required locally.
No passwords/tokens are saved. No existing unrelated repository is overwritten.
#>
[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$')]
    [string]$RepoName = 'collective-llm',
    [switch]$ValidateOnly
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:BaseUrl = 'https://git.m8e.co.uk'
$script:Headers = @{}
$script:Records = @()
$script:StatePath = Join-Path $PSScriptRoot '.gitea-publish-state.json'
$script:ManifestPath = Join-Path $PSScriptRoot 'publish-manifest.json'
$script:ManifestHash = $null
$script:ApiRepoPath = $null
$secureToken = $null
$plainToken = $null
$exitCode = 0

function Save-State {
    param([object]$State)
    $temporary = $script:StatePath + '.tmp'
    $json = ConvertTo-Json -InputObject $State -Depth 12
    [System.IO.File]::WriteAllText($temporary, $json, (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temporary -Destination $script:StatePath -Force
}

function Invoke-Gitea {
    param(
        [ValidateSet('GET','POST')][string]$Method,
        [string]$Path,
        [object]$Body = $null,
        [switch]$Allow404
    )
    if (-not $Path.StartsWith('/') -or $Path.StartsWith('//')) {
        throw 'Invalid API path.'
    }
    $parameters = @{
        Uri = $script:BaseUrl + '/api/v1' + $Path
        Method = $Method
        Headers = $script:Headers
        TimeoutSec = 60
        MaximumRedirection = 0
        UseBasicParsing = $true
        ErrorAction = 'Stop'
    }
    if ($null -ne $Body) {
        $parameters.ContentType = 'application/json; charset=utf-8'
        $parameters.Body = [System.Text.Encoding]::UTF8.GetBytes(
            (ConvertTo-Json -InputObject $Body -Depth 12 -Compress)
        )
    }
    try {
        $result = Invoke-RestMethod @parameters
    }
    catch {
        $code = 0
        try {
            if ($null -ne $_.Exception.Response) {
                $code = [int]$_.Exception.Response.StatusCode
            }
        } catch { $code = 0 }
        if ($Allow404 -and $code -eq 404) { return $null }
        if ($code -eq 401 -or $code -eq 403) {
            throw "Gitea denied $Method $Path (HTTP $code). Check the token's read:user and write:repository permissions and access to private repositories. Cloudflare Access can also block this request."
        }
        if ($code -ge 300 -and $code -lt 400) {
            throw 'The server redirected an API request. Redirects are refused to avoid forwarding credentials. Check the Gitea URL/tunnel and Cloudflare Access.'
        }
        if ($code -ne 0) {
            throw "Gitea returned HTTP $code on $Method $Path. No automatic write retry was attempted. Inspect the repository before retrying."
        }
        throw "Could not complete $Method $Path. Check DNS, HTTPS, the Gitea service and Cloudflare Tunnel from this PC. A failed POST can have an uncertain outcome; inspect the repository before retrying."
    }
    if ($result -is [string]) {
        throw 'Expected a Gitea JSON response but received text/HTML. Check the tunnel and any Cloudflare login/challenge page.'
    }
    return $result
}

function Get-Head {
    $branch = Invoke-Gitea -Method GET -Path ($script:ApiRepoPath + '/branches/main')
    $sha = [string]$branch.commit.id
    if ($sha -notmatch '^[a-fA-F0-9]{40,64}$') { throw 'Gitea returned an invalid main-branch commit ID.' }
    return $sha
}

function Encode-FilePath {
    param([string]$Path)
    return (($Path.Split('/') | ForEach-Object { [Uri]::EscapeDataString($_) }) -join '/')
}

function Get-RemoteFile {
    param([string]$Path, [string]$Commit)
    $encoded = Encode-FilePath -Path $Path
    $ref = [Uri]::EscapeDataString($Commit)
    return (Invoke-Gitea -Method GET -Path ($script:ApiRepoPath + '/contents/' + $encoded + '?ref=' + $ref) -Allow404)
}

function Test-RemoteFiles {
    param([string]$Commit)
    foreach ($record in $script:Records) {
        $remote = Get-RemoteFile -Path $record.path -Commit $Commit
        if ($null -eq $remote -or $remote.type -ne 'file') { return $false }
        if ($remote.encoding -ne 'base64') { return $false }
        try {
            $bytes = [Convert]::FromBase64String([string]$remote.content)
            $algorithm = [System.Security.Cryptography.SHA256]::Create()
            try {
                $digest = ([BitConverter]::ToString($algorithm.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()
            } finally { $algorithm.Dispose() }
        } catch { return $false }
        if ($digest -ne $record.sha256) { return $false }
        Write-Host ('Verified: ' + $record.path)
    }
    return $true
}

function Complete-Publish {
    param([object]$State, [string]$Commit)
    if ((Get-Head) -ne $Commit) {
        throw 'The main branch moved during verification. Re-run to inspect the new head; no content will be overwritten automatically.'
    }
    $State.phase = 'complete'
    $State.commit_sha = $Commit
    Save-State -State $State
    $repoUrl = $script:BaseUrl + '/' + [Uri]::EscapeDataString($State.owner) + '/' + $RepoName
    Write-Host ''
    Write-Host 'SUCCESS: the private repository and all manifest files are verified.'
    Write-Host ('Repository: ' + $repoUrl)
    Write-Host ('Commit: ' + $Commit)
    Write-Host ('Clone command: git clone ' + $repoUrl + '.git')
    Write-Host 'After cloning, open CODEX_START_PROMPT.txt to begin T00.'
    Write-Host 'You may now revoke the temporary publishing token in Gitea.'
}

function Publish-Repository {
    $account = Invoke-Gitea -Method GET -Path '/user'
    $owner = [string]$account.login
    if ([string]::IsNullOrWhiteSpace($owner) -or $owner.Contains('/')) {
        throw 'Could not determine your Gitea account from the authenticated user endpoint.'
    }
    $script:ApiRepoPath = '/repos/' + [Uri]::EscapeDataString($owner) + '/' + [Uri]::EscapeDataString($RepoName)
    Write-Host ('Account: ' + $owner)
    Write-Host ('Destination: ' + $script:BaseUrl + '/' + $owner + '/' + $RepoName + ' (PRIVATE, main)')

    $state = $null
    if (Test-Path -LiteralPath $script:StatePath) {
        $state = Get-Content -LiteralPath $script:StatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.server -ne $script:BaseUrl -or $state.owner -ne $owner -or
            $state.repository -ne $RepoName -or $state.manifest_sha256 -ne $script:ManifestHash) {
            throw 'A previous publishing receipt belongs to another account, repository or package. Use a fresh extraction; nothing was changed remotely.'
        }
    }
    $repository = Invoke-Gitea -Method GET -Path $script:ApiRepoPath -Allow404
    if ($null -ne $repository) {
        if ($null -eq $state -or $null -eq $state.repository_id -or
            [string]$state.repository_id -ne [string]$repository.id) {
            throw 'This repository already exists and was not positively identified as created by this publisher. Nothing was overwritten. Use -RepoName with a new name, or inspect a previous uncertain create request manually.'
        }
    }
    else {
        if ($null -ne $state) {
            throw 'The saved publishing receipt has no matching remote repository. Do not automatically recreate it. Inspect Gitea, then use a fresh extraction and a new repository name.'
        }
        $state = [PSCustomObject]@{
            schema_version = 1
            server = $script:BaseUrl
            owner = $owner
            repository = $RepoName
            repository_id = $null
            manifest_sha256 = $script:ManifestHash
            phase = 'create-requested'
            initial_commit = $null
            commit_sha = $null
        }
        Save-State -State $state
        Write-Host 'Creating the private repository...'
        $repository = Invoke-Gitea -Method POST -Path '/user/repos' -Body @{
            name = $RepoName
            description = 'Collective: modular local multi-model assistant - architecture and Codex build handbook'
            private = $true
            auto_init = $true
            default_branch = 'main'
            readme = 'Default'
        }
        $state.repository_id = $repository.id
        $state.phase = 'created'
        Save-State -State $state
    }

    if ($repository.private -ne $true -or $repository.owner.login -ne $owner -or
        $repository.default_branch -ne 'main') {
        throw 'Repository owner, privacy or branch differs from the intended settings. Stopped without changing repository settings or uploading files.'
    }
    $head = Get-Head
    if ([string]::IsNullOrWhiteSpace([string]$state.initial_commit)) {
        # A new auto-initialized repository should contain only its seed README.
        $entries = @(Invoke-Gitea -Method GET -Path ($script:ApiRepoPath + '/contents?ref=' + [Uri]::EscapeDataString($head)))
        if ($entries.Count -ne 1 -or $entries[0].type -ne 'file' -or $entries[0].path -ne 'README.md') {
            throw 'Expected only the auto-generated README in the new repository. Inspect unexpected content; nothing was overwritten.'
        }
        $state.initial_commit = $head
        Save-State -State $state
    }
    if ($head -ne $state.initial_commit) {
        Write-Host 'The branch advanced since creation. Checking whether this package is already present...'
        if (Test-RemoteFiles -Commit $head) {
            Complete-Publish -State $state -Commit $head
            return
        }
        throw 'The branch changed and does not exactly contain this package. No files were overwritten. Review the repository before proceeding.'
    }

    $operations = @()
    foreach ($record in $script:Records) {
        $operation = @{
            operation = 'create'
            path = [string]$record.path
            content = [Convert]::ToBase64String([IO.File]::ReadAllBytes($record.local_path))
        }
        if ($record.path -eq 'README.md') {
            $seed = Get-RemoteFile -Path 'README.md' -Commit $head
            if ($null -eq $seed -or $seed.type -ne 'file') { throw 'Seed README could not be inspected safely.' }
            $operation.operation = 'update'
            $operation.sha = [string]$seed.sha
        }
        $operations += $operation
    }
    if ((Get-Head) -ne $head) { throw 'The branch changed before upload. Re-run to reconcile; no write was made.' }
    $state.phase = 'upload-requested'
    Save-State -State $state
    Write-Host ('Publishing ' + $operations.Count + ' files in one Git commit through the Gitea API...')
    $null = Invoke-Gitea -Method POST -Path ($script:ApiRepoPath + '/contents') -Body @{
        branch = 'main'
        message = 'docs: add Collective architecture v0.2 and Codex build handoff'
        files = @($operations)
    }
    $publishedHead = Get-Head
    $state.phase = 'verifying'
    $state.commit_sha = $publishedHead
    Save-State -State $state
    if (-not (Test-RemoteFiles -Commit $publishedHead)) {
        throw 'Upload returned, but full byte-level verification did not pass. The repository may contain the files. Inspect it or re-run to reconcile; do not delete or force-push it.'
    }
    Complete-Publish -State $state -Commit $publishedHead
}

try {
    if (-not (Test-Path -LiteralPath $script:ManifestPath -PathType Leaf)) { throw 'publish-manifest.json is missing. Extract the complete ZIP first.' }
    $manifest = Get-Content -LiteralPath $script:ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.schema_version -ne 1) { throw 'Unsupported manifest version.' }
    $script:ManifestHash = (Get-FileHash -LiteralPath $script:ManifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $root = (Get-Item -LiteralPath (Join-Path $PSScriptRoot 'repo')).FullName
    $rootPrefix = $root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $seen = @{}
    foreach ($entry in $manifest.files) {
        $relative = [string]$entry.path
        $parts = $relative.Split('/')
        if ([string]::IsNullOrWhiteSpace($relative) -or $relative.StartsWith('/') -or
            $relative.Contains('\') -or $relative.Contains(':') -or
            ($parts -contains '..') -or ($parts -contains '.') -or ($parts -contains '') -or
            ($parts -contains '.git') -or $seen.ContainsKey($relative)) {
            throw 'Unsafe or duplicate path in the publish manifest.'
        }
        $seen[$relative] = $true
        $local = [IO.Path]::GetFullPath((Join-Path $root $relative.Replace('/',[IO.Path]::DirectorySeparatorChar)))
        if (-not $local.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'A source file escaped the repository folder.' }
        $item = Get-Item -LiteralPath $local -Force
        if ($item.PSIsContainer -or $item.Length -ne $entry.bytes) { throw ('Invalid source file: ' + $relative) }
        $cursor = $item
        while ($null -ne $cursor -and $cursor.FullName -ne $root) {
            if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Symbolic links/junctions are not accepted in the upload package.' }
            if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
        }
        $hash = (Get-FileHash -LiteralPath $local -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.sha256) { throw ('Checksum mismatch: ' + $relative + '. Re-extract the original package.') }
        $script:Records += [PSCustomObject]@{ path=$relative; local_path=$local; sha256=$hash }
    }
    if ($script:Records.Count -eq 0) { throw 'The package contains no files.' }
    Write-Host ('Local package validated: ' + $script:Records.Count + ' files.')
    if (-not $ValidateOnly) {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Write-Host ''
        Write-Host 'Create a temporary token in Gitea: Settings > Applications.'
        Write-Host 'Permissions: read:user and write:repository; allow private repository access.'
        Write-Host 'Use a token that can create new repositories, not one restricted to existing selected repos.'
        Write-Host 'Enter it only here. The publisher does not save the token to disk or a Git remote.'
        $secureToken = Read-Host 'Gitea access token' -AsSecureString
        if ($secureToken.Length -eq 0) { throw 'No token entered.' }
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
        try { $plainToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
        $plainToken = $plainToken.Trim()
        if ([string]::IsNullOrWhiteSpace($plainToken) -or $plainToken -match '\s') { throw 'The token is empty or contains whitespace.' }
        $script:Headers = @{ Authorization = 'token ' + $plainToken; Accept = 'application/json' }
        $plainToken = $null
        Publish-Repository
    }
}
catch {
    Write-Host ''
    Write-Host ('STOPPED: ' + $_.Exception.Message)
    Write-Host 'No repository deletion, force-push, public visibility change or automatic blind write retry was attempted.'
    $exitCode = 1
}
finally {
    $script:Headers.Clear()
    $plainToken = $null
    if ($null -ne $secureToken) { $secureToken.Dispose() }
}
exit $exitCode
