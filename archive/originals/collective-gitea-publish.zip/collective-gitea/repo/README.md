# Collective — local multi-model assistant

**Status: architecture and Codex build handoff, version 0.2. Not a working application.**

A local-first assistant that selectively combines small specialist models behind
one interface, with source-preserving context compaction, indexed lookup, bounded
tool execution, host-controlled permissions and measurable quality gates.

## Start here

- [Architecture blueprint](docs/architecture/collective-llm-architecture.html)
- [Codex starting prompt](CODEX_START_PROMPT.txt)
- [Agent instructions](AGENTS.md)
- [Build brief](docs/CODEX_BUILD_BRIEF.md)
- [Task backlog: T00–T10](docs/BUILD_BACKLOG.md)
- [Module ownership and dependency rules](docs/MODULE_MAP.md)
- [Proposed interface contracts](docs/architecture/ports.example.ts)
- [Proposed configuration](docs/architecture/collective.proposed.json)
- [Progress report template](docs/progress/PROGRESS_TEMPLATE.md)

Download/open the HTML locally in a browser to use its diagrams, navigation and
speed calculator. Do not assume that a Git-hosting file viewer runs its scripts.

## First Codex run

Open this repository in your development environment. Give Codex the contents of
`CODEX_START_PROMPT.txt`. Start with T00 when no implementation exists, implement
one task at a time and record actual verification results. The development commands
in the plan become available as their corresponding tasks are implemented.

## Architectural rules

Use a modular monolith with explicit ports and replaceable adapters. Keep domain
logic independent of inference providers, storage, HTTP and UI. Add distributed
workers only after measurements establish a need. Preserve original evidence and
source references when compacting context. Models request actions; the host checks
permissions and executes them. Model candidates, licences, runtime compatibility,
latency estimates and quality targets must be validated before release.

## Target and exclusions

First target: Windows 11, RTX 3060 12GB, 32GB RAM. No Docker or WSL requirement.
This repository does not contain model weights, an implemented assistant, measured
model benchmarks, secrets, installers for the assistant, or an adopted software
licence. Do not infer rights to third-party models from this handoff.

The original handoff README is retained in `docs/CODEX_HANDOFF_README.md`.
