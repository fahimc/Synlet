# Collective — Codex handoff kit v0.2

This archive contains an architecture document and implementation instructions.
It does NOT contain a working application, model weights, installers or benchmarks.

1. Open docs/architecture/collective-llm-architecture.html in a browser.
2. Inspect the files before merging into your chosen repository. Do not overwrite
   an existing AGENTS.md or project instructions; merge relevant rules deliberately.
3. Give Codex CODEX_START_PROMPT.txt and start with the first unfinished task card.
4. The optional .agents/skills/collective-build/SKILL.md is a development aid only.
5. Commands in the brief/backlog must be implemented by the corresponding tasks.
   They are not commands that this documentation-only archive can run today.

The original model roster, performance calculator and source register are retained.
Build sections add module ownership, contracts, task cards, scaling and maintenance.
Speed values remain estimates; quality thresholds remain proposed acceptance gates.

No source repository was modified or pushed during preparation of this handoff.
